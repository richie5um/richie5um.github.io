#!/bin/bash -l

#echo "$TEXTBAR_DIR"
#env

if [ -n "$TEXTBAR_REFRESH" ]
then
    if [ -n "$TEXTBAR_DIR" ]
    then
        mkdir -p "$TEXTBAR_DIR"
        echo "$TEXTBAR_REFRESH" > "$TEXTBAR_DIR/REFRESH"
    fi
fi

if [ -n "$TEXTBAR_ACTIONSCRIPT" ]
then
    if [ -n "$TEXTBAR_DIR" ]
    then
        mkdir -p "$TEXTBAR_DIR"
        echo "$TEXTBAR_ACTIONSCRIPT" > "$TEXTBAR_DIR/ACTIONSCRIPT"
    fi
fi

if [ -n "$TEXTBAR_STATE" ]
then
    if [ -n "$TEXTBAR_DIR" ]
    then
        mkdir -p "$TEXTBAR_DIR"
        echo "$TEXTBAR_STATE" > "$TEXTBAR_DIR/STATE"
    fi
fi