#!/bin/bash -l

#echo "$TEXTBAR_DIR"
#env

if [ -n "$TEXTBAR_REFRESH" ]
then
    if [ -n "$TEXTBAR_DIR" ]
    then
        mkdir -p "$TEXTBAR_DIR"
        echo "$TEXTBAR_REFRESH" > "$TEXTBAR_DIR/refresh"
    fi
fi

#[ -n "$TEXTBAR_STATE" ] && { mkdir -p "$TEXTBAR_DIR" && echo "$TEXTBAR_STATE" > "$TEXTBAR_DIR/STATE.txt"; exit 1; }
